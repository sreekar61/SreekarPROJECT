package com.rays.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.rays.dao.userdao.UserDao;
import com.rays.model.User;

@Controller
public class UserController {
	
	@Autowired
	User user;
	
	@Autowired
	UserDao userDao;
	
	String msg;
	
	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("user", user);
		model.addAttribute("msg", msg);
		return "index";
	}
	
	@RequestMapping("validate")
	public String validateUser(@ModelAttribute("user") User user,  Model mv, HttpSession session) {
				
		User user1 = userDao.validateUser(user);
		if(user1!=null) {
			msg = "Login Successfull";
			session.setAttribute("user", user.getName());
			System.out.println("Login Successfull");
			return "redirect:/getall";
		}else {
			System.out.println("Login Failed");
			msg = "Login Failed";
			return "redirect:/home";
		}
		
	}

	@RequestMapping("/registeration")
	public String showRegisterationForm(Model model) {
		model.addAttribute("user", user);
		
		//List<String> CityList = Arrays.asList("select","Banglore","Mysore","Manglore","Chennai","Hyderabad","Kochin");
		//model.addAttribute(CityList);
		
           
		return "registeration";
		
	}
	
	@RequestMapping("submitform")
	public ModelAndView saveUser(@ModelAttribute("user") User user, ModelAndView mv, @RequestPart("pics") MultipartFile file) throws IOException {
		System.out.println(user);
		System.out.println("In Save User");
		byte[] Pic = file.getBytes();
		user.setPic(Pic);
		userDao.addUser(user);
		mv.addObject("msg", "User Added Successfully");
		//mv.addObject("user", user);
		mv.setViewName("registeration");
		return mv;
	}
	
	@RequestMapping("getall")
	public ModelAndView getAllUser(ModelAndView mv) {
		List<User> userList = userDao.getAllUser();
		mv.addObject("users", userList);
		mv.addObject("msg", msg);
		mv.setViewName("viewusers");
		return mv;
	}
	
	@RequestMapping("getuserform")
	public String getUserForm() {
		return "getuser";
	}
	
	@RequestMapping("getbyid")
	public ModelAndView getById(@RequestParam("id") int id, ModelAndView mv) {
		User user = userDao.getUserById(id);
		mv.addObject("user", user);
		mv.setViewName("showuser");
		return mv;
	}
	
	@RequestMapping("updateuser/{id}")
	public String getUpdateUser(@PathVariable int id, Model m) {
		
		User user = userDao.getUserById(id);
		System.out.println("In Controller : "+user);
		m.addAttribute("user", user);
		return "updateform";
		
	}
	
	@RequestMapping("saveupdate")
	public String saveUpdate(@ModelAttribute("user") User user) {
		userDao.updateUser(user);
		return "redirect:/getall";
		
	}
	
	@RequestMapping("deleteuser/{id}")
	public String deleteUser(@PathVariable int id) {
		userDao.deleteUser(id);
		return "redirect:/getall";
	}
}

package com.rays.model;

import java.util.Date;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	//@Column(name = "uname")
	private String name;
	private String password;
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private Date dob;
	private String state;
	private String city;
	private String aadhar;
	private Long mobile;
	private Integer height;
	private String gender;
	private String role;
	private String battingStyle;
	private String bowlingStyle;
	@Lob
	private byte[] pic;
	private String agree;


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(Integer id, String name, String password, Date dob, String state, String city, String aadhar,
			Long mobile, Integer height, String gender, String role, String battingStyle, String bowlingStyle,
			byte[] pic, String agree) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.dob = dob;
		this.state = state;
		this.city = city;
		this.aadhar = aadhar;
		this.mobile = mobile;
		this.height = height;
		this.gender = gender;
		this.role = role;
		this.battingStyle = battingStyle;
		this.bowlingStyle = bowlingStyle;
		this.pic = pic;
		this.agree = agree;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getAadhar() {
		return aadhar;
	}


	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}


	public Long getMobile() {
		return mobile;
	}


	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}


	public Integer getHeight() {
		return height;
	}


	public void setHeight(Integer height) {
		this.height = height;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getBattingStyle() {
		return battingStyle;
	}


	public void setBattingStyle(String battingStyle) {
		this.battingStyle = battingStyle;
	}


	public String getBowlingStyle() {
		return bowlingStyle;
	}


	public void setBowlingStyle(String bowlingStyle) {
		this.bowlingStyle = bowlingStyle;
	}


	public byte[] getPic() {
		return pic;
	}


	public void setPic(byte[] pic) {
		this.pic = pic;
	}


	public String getAgree() {
		return agree;
	}


	public void setAgree(String agree) {
		this.agree = agree;
	}

	public String getUserPicture() {
		return Base64.encodeBase64String(pic);
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", password=" + password + ", dob=" + dob + ", state=" + state
				+ ", city=" + city + ", aadhar=" + aadhar + ", mobile=" + mobile + ", height=" + height + ", gender="
				+ gender + ", role=" + role + ", battingStyle=" + battingStyle + ", bowlingStyle=" + bowlingStyle
				+ ", pic=" + Arrays.toString(pic) + ", agree=" + agree + "]";
	}
	

}
